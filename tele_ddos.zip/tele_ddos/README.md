//Buatan Deby [ t.me/DebyWangsaff ]
//Jangan Hapus BAGIAN INI DAN NGAKU NGAKU
//Hapus bagian ini? jahanam wait for. you
//BOT TELE DDOS V2 [Beta]
//Developer: t.me/DebyWangsaff
//Creator: t.me/DebyWangsaff

buat Anak JB, jangan ngaku ngaku buatan kalian !!

Bantu Subs Yt Saya Untuk Info Terbaru
https://www.youtube.com/@Deby_attckr

npm i fake-useragent request url tls http http2 cloudscraper randomstring events cluster net fs crypto colors node-telegram-bot-api gradient-string requests axios telegraf express child_process

salin dan tempel di terminal untuk instal module